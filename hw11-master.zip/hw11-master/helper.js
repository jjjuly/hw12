//
const TelegramBot = require('node-telegram-bot-api');
const {promisify} = require('util');
const appendFile = promisify(require('fs').appendFile);
const mkdirp = require('mkdirp');
const moment = require('moment');

//
const helper = {};
//
const bot = new TelegramBot('580129897:AAFbwyVX568bJ5OphXKPfXMlAFikGwRrt4w', {polling: true, request: {proxy:"http://37.59.8.29:1034"}});
bot.on('message', async(msg) => {
	bot.sendMessage(msg.chat.id, 'NotifyBot started');
});
//const bot = new TelegramBot('474976789:AAGim9ZkwrsH-C3YUj_-UPd-sq1eNN3rrMA', {polling: true});
bot.on('message', async(msg) => {
	let tm = await models.TelegramUser.find({id: msg.chat.id});
	if(tm.length == 0) {
		tm = await models.TelegramUser();
		tm.id = msg.chat.id;
		await tm.save();
		bot.sendMessage(tm.id, 'NotifyBot started');
	} else {
		tm = tm[0];
	}
});
//bot.sendMessage(msg.chat.chatId, message);
mkdirp('./logs');
//
//добавлен третий аргумент, assync
helper.sendErr = async function(res, message, err = undefined) {
//
	if (err != undefined) {
		let errOut = (err.stack || err) + '\n\n';
		let fileDate = moment().format('DD-MM-YYYY');
		//await appenFile('./logs/err.log', e, 'utf-8');
		await appendFile(`./logs/err-${fileDate}.log`, errOut, 'utf-8');
		let tms = await models.TelegramUser.find();
		for (let tm of tms) {
			bot.sendMessage(tm.id, errOut);
		}
	};
//
	return res.send({
		err: message
	});
};

helper.postLimit = 20;
helper.userLimit = 5;

module.exports = helper;